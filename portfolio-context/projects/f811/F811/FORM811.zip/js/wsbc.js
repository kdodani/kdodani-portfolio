$(document).ready(function () {
    // quill html editor

    // NOTE: The following code demostrated that you can
    //   1. set the content of the text editor using deltas.
    //   2. read the deltas content of the text editor which will be persistent via backend API call.
    //   3. using dangerouslyPasteHTML to do one time conversion from HTML to deltas.
    Quill.prototype.getHtml = function() {
        return this.container.querySelector('.ql-editor').innerHTML;
    };

    let quill = new Quill('#editor-container', {
        modules: {
          toolbar: [
            ['bold', 'italic', 'underline'],
            [{ 'script': 'sub'}, { 'script': 'super' }],
            [{ 'list': 'ordered'}, { 'list': 'bullet' }],
            ['link']
          ]
        },
        placeholder: 'Please provide feedback',
        theme: 'snow'  // or 'bubble'
    });

    $('#htom_editor_set_html').on('click', function() {
        quill.clipboard.dangerouslyPasteHTML(`
            <p>This is our standard paragraph text. </p>
            <p><strong>This is our bold text.</strong></p>
            <p><a href="https://www.worksafebc.com">Home</a></p>
            `);
    });

    let quill_readonly= new Quill('#editor-container-readyonly', {
        readonly: true,
    });
    quill_readonly.disable();

    quill.on('text-change', function() {
        quill_readonly.setContents(quill.getContents());
        $('#html-container').html(quill_readonly.getHtml());
        // console.log(quill_readonly.getHtml(), quill.getContents());
    });

    quill.setContents([
        { insert: 'Hello ' },
        { insert: 'World!', attributes: { bold: true } },
        { insert: '\n' },
      ]);


   // redirect to site with bootstrap 5
   $('#bootstrap-selector').on('change', function(){
        if ($(this).val() === '5') {
            // window.location.href = 'https://google.com';
            window.location.href = window.location.href.replace(/(.*\/\/[^/]*)\/(.*)/, '$1/bs5/$2');

            // NOTE: when we click back button, the dropdown is not showing correctly without the following line
            $(this).val('4');
        }
    })

    //ACCORDION
    // Add minus icon for collapse element which is open by default
    $(".collapse.show").each(function () {
        $(this).prev(".card-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
    });

    // Toggle plus minus icon on show hide of collapse element
    $(".collapse").on('show.bs.collapse', function () {
        $(this).parent().addClass('active');
        $(this).prev(".card-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
    }).on('hide.bs.collapse', function () {
        $(this).parent().removeClass('active');
        $(this).prev(".card-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
    });


    //HAMBURGER MENU
    $('.hamburger-menu button, .close-menu').click(function (event) {
        $('.hamburgerMenu-content').toggleClass('width');
        event.preventDefault();
    })

    $('.hamburgerMenu-content ul li a').click(function () {
        $('.hamburgerMenu-content').toggleClass('width');
    })


    //OPACITY

    var cssText = "";
    var css = document.createElement("style");
    css.type = "text/css";
    $('.blackModal').on('show.bs.modal', function (e) {
        cssText = ".modal-backdrop.show { background-color: black;}";
        if ("textContent" in css) {
            css.textContent = cssText;
        }
        else {
            css.innerText = cssText;
        }
        document.body.appendChild(css);
    });

    $('.blackModal').on('hidden.bs.modal', function () {
        document.body.removeChild(css);
    });

    $('.whiteModal').on('show.bs.modal', function (e) {
        cssText = ".modal-backdrop.show { background-color: white; opacity: .95 !important}";
        if ("textContent" in css) {
            css.textContent = cssText;
        }
        else {
            css.innerText = cssText;
        }
        document.body.appendChild(css);
    });

    $('.whiteModal').on('hidden.bs.modal', function () {
        document.body.removeChild(css);
    })


    //EXPANDABLE TABLES
    $('.table-accordion-btn').click(function () {
        // debugger;
        $('.table-accordion-btn tr td').find('a').attr('aria-expanded', false)


        if(!($(this).parent().find('a').attr('aria-expanded'))){
            $(this).find('i').css({transform: 'rotate 100deg'});
        }
        $(this).find('i').toggleClass('open')
        $(this).parent().parent().toggleClass('accordion-toggle');

        $(this).parents('tr').css({"border": "2px solid #6399AE", "border-bottom-width": "0"});
        $(this).parents('tr').next('tr').css({"border": "2px solid #6399AE", "border-top-width": "0"});
        if($(this).parents('tr').next('tr').find('div').hasClass('show')){
            $(this).parents('tr').css({"border-width": "0"});
            $(this).parents('tr').next('tr').css({"border-width": "0"});
        }

    })

    var _dataObj;
    $.getJSON("../json/data.json", function(data){
    _dataObj = data;
    console.log(data)
    }).fail(function(){
        console.log('JSON not found')
    })
$('.show-desc-info').click(function(){
  let name = $(this).attr('id');
  let modalBody = $($($(this).attr('data-target')).find('.modal-body'));
  let modalTitle = $($($(this).attr('data-target')).find('.modal-title'));

  let title = _dataObj.usageDescriptionList[name].title;
  let description = _dataObj.usageDescriptionList[name].description;
  let _descArray = _dataObj.usageDescriptionList[name].usageRules;

  let _content ='';
  _descArray.forEach(function(data, i){
    if(data){
      _content +=  "<li>"+ data + "</li>"
    }

  })
  _content= "<div><h3>Description</h3><p>"+ description +"</p><h3>Usage Rules</h3><ul>"+ _content + "</ul></div>";
  modalBody.html(_content);
  modalTitle.text(title)
})

var table = $('.sortable-table');

$('.sort')
    .wrapInner('<span title="sort this column"/>')
    .each(function(){

        var th = $(this),
            thIndex = th.index(),
            inverse = false;

        th.click(function(){

            table.find('td').filter(function(){

                return $(this).index() === thIndex;

            }).sortElements(function(a, b){

                return $.text([a]) > $.text([b]) ?
                    inverse ? -1 : 1
                    : inverse ? 1 : -1;

            }, function(){

                // parentNode is the element we want to move
                return this.parentNode;

            });

            inverse = !inverse;

        });

    });


    $('a.show-pop').webuiPopover();

});


//TOASTER
var obj = {};
var arr_obj = [];
var offset = 0;
const MAX_ALLOWED_INCREMENT = 80;

function recalculateHide(id) {
    var index = arr_obj.findIndex(obj => obj.id === id);
    for (let i = index; i < arr_obj.length - 1; i++) {
        arr_obj[i + 1].top = arr_obj[i + 1].top - MAX_ALLOWED_INCREMENT;

        $('#' + arr_obj[i + 1].id).animate({
            opacity: 1,
            zIndex: 0,
            top: arr_obj[i + 1].top,

        }, 250, function () {
        });

    }
    offset = arr_obj[arr_obj.length - 1].top;
    //remove the current obj with the current id
    arr_obj = arr_obj.filter(obj => obj.id !== id);
}




function initialize(id) {
    if (!$('#' + id).hasClass("show")) {
        obj = {};
        if (arr_obj.length === 0) {
            offset = 30;
            obj['id'] = id;
            obj['status'] = 'show';
            obj['top'] = offset;
            arr_obj.push(obj);
        } else {
            offset += 80;
            obj['id'] = id;
            obj['status'] = 'show';
            obj['top'] = offset;
            arr_obj.push(obj);
        }
        return (offset);
    }
}



function showToast(id, delay) {
    var newtop = initialize(id);
    $('#' + id).animate({
        opacity: 1,
        zIndex: 2,
        top: newtop,

    }, 350, function () {
        // Animation complete.
    });

    $('#' + id).addClass("show");
    if (delay) {
        setTimeout(() => { hideToast(id) }, 5000, id);
    }
}
function hideToast(id) {
    $('#' + id).animate({
        opacity: 0,
        zIndex: 0,
        top: 0,
    }, 250, function () {
        // Animation complete.
    });
    $('#' + id).removeClass("show");
    recalculateHide(id);
}


//TEXTAREA

function countChar(val) {
    var len = val.value.length;
    var maxLen = 141 - len;
    // $('#regexError').text('');
    // var regex = /^[a-zA-Z0-9 ]*$/;
    var textbox = document.getElementById("field");
    // ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {

    // textbox.addEventListener(event, function(){
    //     if(!regex.test(this.value) ) {
    //         document.getElementById('regexError').innerHTML = 'Please do not use symbols such as ! @ # $ % ^ & * ( ) _ +';
    //     } else {
    //         document.getElementById('regexError').innerHTML = ''
    //     }
    // })

    // });

    if (len >= 140) {
        $('#charLenght').text('You have exceeded the 140 characters limit').addClass('text-danger')
        $('#field').css("border-color", "#DC4405")
        $('#field').focus(function () {
            $(this).css("border-color", "#DC4405")
        })
    }
    else {

        $('#charLenght').text(maxLen - 1 + ' characters avaliable').removeClass('text-danger')
        // $('#field').css("border-color","#928B83")
        $('#field').focus(function () {
            // $(this).css("border-color","#928B83")
        })
    }
    if (len >= 140) {

        $('#charLenght').text('You are ' + (len - 140) + ' characters over the limit').addClass('text-danger')
        // $('#field').css("border-color","#928B83")
        // $('#field').focus(function(){
        //     // $(this).css("border-color","#928B83")
        // })
    }
};



//SELECTMENU
$(".custom-select-dropdown").on("click", ".init", function () {
    $(this).closest(".custom-select-dropdown").find('li:not(.init)').toggle();
    var showListItems = $(this).closest(".custom-select-dropdown").find('li:not(.init)').css('display')
    if (showListItems == "none")
        $(this).closest(".custom-select-dropdown").css("border-width", "1px")
    else
        $(this).closest(".custom-select-dropdown").css("border-width", "2px")
});

var allOptions = $(".custom-select-dropdown").find('li:not(.init)');
$(".custom-select-dropdown").on("click", "li:not(.init)", function () {
    $(this).closest(".custom-select-dropdown").css("border-width", "1px")
    allOptions.removeClass('selected');
    $(this).addClass('selected');
    $(".custom-select-dropdown").find('.init').html($(this).html());
    allOptions.toggle();
});

//SCREENSHOOTER


if (window.ss_index === undefined) {

    function eventFire(el, etype) {
        if (el.fireEvent) {
            el.fireEvent('on' + etype);
        } else {
            var evObj = document.createEvent('Events');
            evObj.initEvent(etype, true, false);
            el.dispatchEvent(evObj);
        }
    }


    if ($(window).width() > 1300) {

        //  Manually triggerring click event to the modal button by giving id as "MODALLARGE"
        eventFire(document.getElementById('modallarge'), 'click');
    }


    if ($(window).width() > 800 && $(window).width() < 1300) {


        //  Manually triggerring click event to the modal button by giving id as "MODALMEDIUM"
        eventFire(document.getElementById('modalmedium'), 'click');
    }

    if ($(window).width() < 800) {

        //  Manually triggerring click event to the modal button by giving id as "MODALSMALL"
        eventFire(document.getElementById('modalsmall'), 'click');
    }
}


//TOOLTIP
$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
});

//COPY
$(document).ready(function () {
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
    $('.copy-btn').click(function () {
        var _this = $(this);
        var $temp = $("<textarea>");
        $("body").append($temp);
        if(_this.parent().parent().find('.copy-code-link').length > 0){
            $temp.val(_this.parent().parent().find('.copy-code-link').text()).select();
        }
        else if(_this.parent().find('.copy-code-link').length > 0){
            $temp.val(_this.parent().find('.copy-code-link').text()).select();
        } else {
            $temp.val(_this.parentsUntil('.elementwrapper').siblings().closest('div').find('.copyToClipBoard').html()).select();
        }
        // console.log($temp.val($('.copyToClipboard').html()))
        document.execCommand("copy");
        $temp.remove();
        var elOriginalText = _this.attr('data-original-title');

        var msg = 'Copied!';
        _this.attr('data-original-title', msg).tooltip('show');

        _this.attr('data-original-title', elOriginalText);
        setTimeout(() => {
            _this.attr('data-original-title', 'Copy to clipboard').tooltip('hide');
        }, 500);
    })

    $('.popover-bottom-left a').popover({container: '.popover-bottom-left'});
    $('.popover-bottom-center a').popover({container: '.popover-bottom-center'});
    $('.popover-bottom-right a').popover({container: '.popover-bottom-right'});

    $('#upload').change(function () {
              var filename = $('#upload').val();
              if (filename.substring(3, 11) == 'fakepath') {
                  filename = filename.substring(12);
              }
              $("label[for='file_name'] b").html(filename);
              $('#fileName').html(`<b>${filename}</b>`)
              if (filename == "") {
                  $("label[for='file_default']").text('No File Choosen');
              }
          });
})



//CHARTS

am4core.useTheme(am4themes_animated);


// Create chart instance
var chart = am4core.create("chartdiv", am4charts.XYChart);

// Add data
chart.data = [{
    "year": "0.5",
    "italy": -10,
    "germany": 5,
    "uk": 3
}, {
    "year": "1",
    "italy": -10,
    "germany": 2,
    "uk": 6
}, {
    "year": "2",
    "italy": 2,
    "germany": 3,
    "uk": 1
}, {
    "year": "3",
    "italy": 3,
    "germany": 4,
    "uk": 1
}, {
    "year": "4",
    "italy": 5,
    "germany": 1,
    "uk": 2
}, {
    "year": "5",
    "italy": 3,
    "germany": 2,
    "uk": 1
}, {
    "year": "6",
    "italy": 1,
    "germany": 7,
    "uk": 3
}, {
    "year": "7",
    "italy": 2,
    "germany": 1,
    "uk": 5
}, {
    "year": "8",
    "italy": 3,
    "germany": 5,
    "uk": 2
}, {
    "year": "9",
    "italy": 4,
    "germany": 3,
    "uk": 6
}, {
    "year": "10",
    "italy": 1,
    "germany": 2,
    "uk": 4
}];

chart.colors.list = [
    am4core.color("#6399AE"),
    am4core.color("#C1D6DF"),
    am4core.color("#8067dc"),
    am4core.color("#a367dc")
];

// Create category axis
var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "year";
categoryAxis.renderer.opposite = true;
categoryAxis.renderer.minGridDistance = 10;

// Create value axis
var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
valueAxis.renderer.inversed = true;
valueAxis.title.text = "Db";
var valueAxis1 = chart.xAxes.push(new am4charts.ValueAxis());
valueAxis1.title.text = " Frequency(Khz)";


// Create series
var series1 = chart.series.push(new am4charts.LineSeries());
series1.dataFields.valueY = "italy";
series1.dataFields.categoryX = "year";
series1.name = "Jun 8, 2019";
series1.strokeWidth = 3;
series1.bullets.push(new am4charts.CircleBullet());
series1.tooltipText = "Place taken by {name} in {categoryX}: {valueY}";
series1.legendSettings.valueText = "{valueY}";


var series2 = chart.series.push(new am4charts.LineSeries());
series2.dataFields.valueY = "germany";
series2.dataFields.categoryX = "year";
series2.name = 'Feb 18, 2020';
series2.strokeWidth = 3;
series2.bullets.push(new am4charts.CircleBullet());
series2.tooltipText = "Place taken by {name} in {categoryX}: {valueY}";
series2.legendSettings.valueText = "{valueY}";



// Add legend
chart.legend = new am4charts.Legend();


// Add simple bullet
var bullet = series1.bullets.push(new am4charts.Bullet());
var image = bullet.createChild(am4core.Image);
image.href = "https://ux-static.online.dv.worksafebc.com/css/assets/img/xicon.svg";
image.width = 15;
image.height = 15;
image.horizontalCenter = "middle";
image.verticalCenter = "middle";

// Add simple bullet
var bullet = series2.bullets.push(new am4charts.Bullet());
var image = bullet.createChild(am4core.Image);
image.href = "https://ux-static.online.dv.worksafebc.com/css/assets/img/xicon-lightblue.svg";
image.width = 15;
image.height = 15;
image.horizontalCenter = "middle";
image.verticalCenter = "middle";






// Create chart instance
var chart = am4core.create("chartdiv1", am4charts.XYChart);

// Add data
chart.data = [{
    "year": "0.5",
    "italy": -10,
    "germany": 5,
    "uk": 3
}, {
    "year": "1",
    "italy": -10,
    "germany": 2,
    "uk": 6
}, {
    "year": "2",
    "italy": 2,
    "germany": 3,
    "uk": 1
}, {
    "year": "3",
    "italy": 3,
    "germany": 4,
    "uk": 1
}, {
    "year": "4",
    "italy": 5,
    "germany": 1,
    "uk": 2
}, {
    "year": "5",
    "italy": 3,
    "germany": 2,
    "uk": 1
}, {
    "year": "6",
    "italy": 1,
    "germany": 7,
    "uk": 3
}, {
    "year": "7",
    "italy": 2,
    "germany": 1,
    "uk": 5
}, {
    "year": "8",
    "italy": 3,
    "germany": 5,
    "uk": 2
}, {
    "year": "9",
    "italy": 4,
    "germany": 3,
    "uk": 6
}, {
    "year": "10",
    "italy": 1,
    "germany": 2,
    "uk": 4
}];

chart.colors.list = [
    am4core.color("#a4343a"),
    am4core.color("#dc4405")
];

// Create category axis
var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "year";
categoryAxis.renderer.opposite = true;
categoryAxis.renderer.minGridDistance = 10;

// Create value axis
var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
valueAxis.renderer.inversed = true;
valueAxis.title.text = "Db";
var valueAxis1 = chart.xAxes.push(new am4charts.ValueAxis());
valueAxis1.title.text = " Frequency(Khz)";
// valueAxis.renderer.minLabelPosition = 0.01;

// Create series
var series1 = chart.series.push(new am4charts.LineSeries());
series1.dataFields.valueY = "italy";
series1.dataFields.categoryX = "year";
series1.name = "Jun 8, 2019";
series1.strokeWidth = 3;
series1.bullets.push(new am4charts.CircleBullet());
series1.tooltipText = "Place taken by {name} in {categoryX}: {valueY}";
series1.legendSettings.valueText = "{valueY}";
// series1.visible  = false;

var series2 = chart.series.push(new am4charts.LineSeries());
series2.dataFields.valueY = "germany";
series2.dataFields.categoryX = "year";
series2.name = 'Feb 18, 2020';
series2.strokeWidth = 3;
series2.bullets.push(new am4charts.CircleBullet());
series2.tooltipText = "Place taken by {name} in {categoryX}: {valueY}";
series2.legendSettings.valueText = "{valueY}";


// Add legend
chart.legend = new am4charts.Legend();




// Create chart instance
var chart = am4core.create("chartdiv2", am4charts.XYChart);

// Add data
chart.data = [{
    "year": "0.5",
    "italy": -10,
    "germany": 5,
    "uk": 3
}, {
    "year": "1",
    "italy": -10,
    "germany": 2,
    "uk": 6
}, {
    "year": "2",
    "italy": 2,
    "germany": 3,
    "uk": 1
}, {
    "year": "3",
    "italy": 3,
    "germany": 4,
    "uk": 1
}, {
    "year": "4",
    "italy": 5,
    "germany": 1,
    "uk": 2
}, {
    "year": "5",
    "italy": 3,
    "germany": 2,
    "uk": 1
}, {
    "year": "6",
    "italy": 1,
    "germany": 7,
    "uk": 3
}, {
    "year": "7",
    "italy": 2,
    "germany": 1,
    "uk": 5
}, {
    "year": "8",
    "italy": 3,
    "germany": 5,
    "uk": 2
}, {
    "year": "9",
    "italy": 4,
    "germany": 3,
    "uk": 6
}, {
    "year": "10",
    "italy": 1,
    "germany": 2,
    "uk": 4
}];

chart.colors.list = [
    am4core.color("#6399AE")
];

// Create category axis
var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "year";
categoryAxis.renderer.opposite = true;
categoryAxis.renderer.minGridDistance = 10;

// Create value axis
var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
valueAxis.renderer.inversed = true;
valueAxis.title.text = "Db";
var valueAxis1 = chart.xAxes.push(new am4charts.ValueAxis());
valueAxis1.title.text = " Frequency(Khz)";
// valueAxis.renderer.minLabelPosition = 0.01;

// Create series
var series1 = chart.series.push(new am4charts.LineSeries());
series1.dataFields.valueY = "italy";
series1.dataFields.categoryX = "year";
series1.name = "Jun 8, 2019";
series1.strokeWidth = 3;
series1.bullets.push(new am4charts.CircleBullet());
series1.tooltipText = "Place taken by {name} in {categoryX}: {valueY}";
series1.legendSettings.valueText = "{valueY}";
// series1.visible  = false;




// Add legend
chart.legend = new am4charts.Legend();

// Add simple bullet
var bullet = series1.bullets.push(new am4charts.Bullet());
var image = bullet.createChild(am4core.Image);
image.href = "https://ux-static.online.dv.worksafebc.com/css/assets/img/xicon.svg";
image.width = 15;
image.height = 15;
image.horizontalCenter = "middle";
image.verticalCenter = "middle";







// Create chart instance
var chart = am4core.create("chartdiv3", am4charts.XYChart);

// Add data
chart.data = [{
    "year": "0.5",
    "italy": -10,
    "germany": 5,
    "uk": 3
}, {
    "year": "1",
    "italy": -10,
    "germany": 2,
    "uk": 6
}, {
    "year": "2",
    "italy": 2,
    "germany": 3,
    "uk": 1
}, {
    "year": "3",
    "italy": 3,
    "germany": 4,
    "uk": 1
}, {
    "year": "4",
    "italy": 5,
    "germany": 1,
    "uk": 2
}, {
    "year": "5",
    "italy": 3,
    "germany": 2,
    "uk": 1
}, {
    "year": "6",
    "italy": 1,
    "germany": 7,
    "uk": 3
}, {
    "year": "7",
    "italy": 2,
    "germany": 1,
    "uk": 5
}, {
    "year": "8",
    "italy": 3,
    "germany": 5,
    "uk": 2
}, {
    "year": "9",
    "italy": 4,
    "germany": 3,
    "uk": 6
}, {
    "year": "10",
    "italy": 1,
    "germany": 2,
    "uk": 4
}];

chart.colors.list = [
    am4core.color("#a4343a")

];

// Create category axis
var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "year";
categoryAxis.renderer.opposite = true;
categoryAxis.renderer.minGridDistance = 10;

// Create value axis
var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
valueAxis.renderer.inversed = true;
valueAxis.title.text = "Db";
var valueAxis1 = chart.xAxes.push(new am4charts.ValueAxis());
valueAxis1.title.text = " Frequency(Khz)";


// Create series
var series1 = chart.series.push(new am4charts.LineSeries());
series1.dataFields.valueY = "italy";
series1.dataFields.categoryX = "year";
series1.name = "Jun 8, 2019";
series1.strokeWidth = 3;
series1.bullets.push(new am4charts.CircleBullet());
series1.tooltipText = "Place taken by {name} in {categoryX}: {valueY}";
series1.legendSettings.valueText = "{valueY}";
chart.legend = new am4charts.Legend();


//DECIMAL

function formatValue(val, prefix) {
    let formatted = val.value.replace(/\D/g, '');
    convertedValue = formatted.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
    if (val.value === '' || val.value === '$ ') {
        val.value = convertedValue;
    } else if (prefix == '$') {
        val.value = '$ ' + convertedValue;
    } else {
        val.value = convertedValue;
    }
}

//MUTE FIELD
$('#enableDisableInput').click(function () {
    if ($(this).is(':checked') == true) {
        $('.toggleEnableDisableInput').prop('disabled', false).val('');
    }
    else {
        $('.toggleEnableDisableInput').prop('disabled', true).val('');
    }
})

//CHECKBOX BUTTON
$('.btn-chckbox').click(function (e) {
    e.preventDefault();
    e.stopPropagation();
    var selecter = $(this);
    if (this.nodeName === 'LABEL') {
        selecter = $(this).parent();
    }
    selecter.toggleClass("btn-outline-blue")
    selecter.toggleClass("btn-blue")
    var checkBoxes = selecter.find('.input-btn-chkbox')
    checkBoxes.prop("checked", !checkBoxes.prop("checked"));
})


// SEARCH

$(".transparent").each(function () {

    var $inp = $(this).find("input:text"),
        $cle = $(this).find(".clearable__clear");

    $inp.on("input", function () {
        $cle.toggle(!!this.value);
    });

    $cle.on("touchstart click", function (e) {
        e.preventDefault();
        $inp.val("").trigger("input");
    });

});

// PRISM

/* http://prismjs.com/download.html?themes=prism&languages=markup+css+clike+javascript */
var _self = "undefined" != typeof window ? window : "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? self : {}, Prism = function () { var e = /\blang(?:uage)?-(\w+)\b/i, t = 0, n = _self.Prism = { manual: _self.Prism && _self.Prism.manual, util: { encode: function (e) { return e instanceof a ? new a(e.type, n.util.encode(e.content), e.alias) : "Array" === n.util.type(e) ? e.map(n.util.encode) : e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ") }, type: function (e) { return Object.prototype.toString.call(e).match(/\[object (\w+)\]/)[1] }, objId: function (e) { return e.__id || Object.defineProperty(e, "__id", { value: ++t }), e.__id }, clone: function (e) { var t = n.util.type(e); switch (t) { case "Object": var a = {}; for (var r in e) e.hasOwnProperty(r) && (a[r] = n.util.clone(e[r])); return a; case "Array": return e.map && e.map(function (e) { return n.util.clone(e) }) }return e } }, languages: { extend: function (e, t) { var a = n.util.clone(n.languages[e]); for (var r in t) a[r] = t[r]; return a }, insertBefore: function (e, t, a, r) { r = r || n.languages; var i = r[e]; if (2 == arguments.length) { a = arguments[1]; for (var l in a) a.hasOwnProperty(l) && (i[l] = a[l]); return i } var o = {}; for (var s in i) if (i.hasOwnProperty(s)) { if (s == t) for (var l in a) a.hasOwnProperty(l) && (o[l] = a[l]); o[s] = i[s] } return n.languages.DFS(n.languages, function (t, n) { n === r[e] && t != e && (this[t] = o) }), r[e] = o }, DFS: function (e, t, a, r) { r = r || {}; for (var i in e) e.hasOwnProperty(i) && (t.call(e, i, e[i], a || i), "Object" !== n.util.type(e[i]) || r[n.util.objId(e[i])] ? "Array" !== n.util.type(e[i]) || r[n.util.objId(e[i])] || (r[n.util.objId(e[i])] = !0, n.languages.DFS(e[i], t, i, r)) : (r[n.util.objId(e[i])] = !0, n.languages.DFS(e[i], t, null, r))) } }, plugins: {}, highlightAll: function (e, t) { var a = { callback: t, selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code' }; n.hooks.run("before-highlightall", a); for (var r, i = a.elements || document.querySelectorAll(a.selector), l = 0; r = i[l++];)n.highlightElement(r, e === !0, a.callback) }, highlightElement: function (t, a, r) { for (var i, l, o = t; o && !e.test(o.className);)o = o.parentNode; o && (i = (o.className.match(e) || [, ""])[1].toLowerCase(), l = n.languages[i]), t.className = t.className.replace(e, "").replace(/\s+/g, " ") + " language-" + i, o = t.parentNode, /pre/i.test(o.nodeName) && (o.className = o.className.replace(e, "").replace(/\s+/g, " ") + " language-" + i); var s = t.textContent, u = { element: t, language: i, grammar: l, code: s }; if (n.hooks.run("before-sanity-check", u), !u.code || !u.grammar) return u.code && (n.hooks.run("before-highlight", u), u.element.textContent = u.code, n.hooks.run("after-highlight", u)), n.hooks.run("complete", u), void 0; if (n.hooks.run("before-highlight", u), a && _self.Worker) { var g = new Worker(n.filename); g.onmessage = function (e) { u.highlightedCode = e.data, n.hooks.run("before-insert", u), u.element.innerHTML = u.highlightedCode, r && r.call(u.element), n.hooks.run("after-highlight", u), n.hooks.run("complete", u) }, g.postMessage(JSON.stringify({ language: u.language, code: u.code, immediateClose: !0 })) } else u.highlightedCode = n.highlight(u.code, u.grammar, u.language), n.hooks.run("before-insert", u), u.element.innerHTML = u.highlightedCode, r && r.call(t), n.hooks.run("after-highlight", u), n.hooks.run("complete", u) }, highlight: function (e, t, r) { var i = n.tokenize(e, t); return a.stringify(n.util.encode(i), r) }, matchGrammar: function (e, t, a, r, i, l, o) { var s = n.Token; for (var u in a) if (a.hasOwnProperty(u) && a[u]) { if (u == o) return; var g = a[u]; g = "Array" === n.util.type(g) ? g : [g]; for (var c = 0; c < g.length; ++c) { var h = g[c], f = h.inside, d = !!h.lookbehind, m = !!h.greedy, p = 0, y = h.alias; if (m && !h.pattern.global) { var v = h.pattern.toString().match(/[imuy]*$/)[0]; h.pattern = RegExp(h.pattern.source, v + "g") } h = h.pattern || h; for (var b = r, k = i; b < t.length; k += t[b].length, ++b) { var w = t[b]; if (t.length > e.length) return; if (!(w instanceof s)) { h.lastIndex = 0; var _ = h.exec(w), P = 1; if (!_ && m && b != t.length - 1) { if (h.lastIndex = k, _ = h.exec(e), !_) break; for (var A = _.index + (d ? _[1].length : 0), j = _.index + _[0].length, x = b, O = k, S = t.length; S > x && (j > O || !t[x].type && !t[x - 1].greedy); ++x)O += t[x].length, A >= O && (++b, k = O); if (t[b] instanceof s || t[x - 1].greedy) continue; P = x - b, w = e.slice(k, O), _.index -= k } if (_) { d && (p = _[1].length); var A = _.index + p, _ = _[0].slice(p), j = A + _.length, N = w.slice(0, A), C = w.slice(j), E = [b, P]; N && (++b, k += N.length, E.push(N)); var L = new s(u, f ? n.tokenize(_, f) : _, y, _, m); if (E.push(L), C && E.push(C), Array.prototype.splice.apply(t, E), 1 != P && n.matchGrammar(e, t, a, b, k, !0, u), l) break } else if (l) break } } } } }, tokenize: function (e, t) { var a = [e], r = t.rest; if (r) { for (var i in r) t[i] = r[i]; delete t.rest } return n.matchGrammar(e, a, t, 0, 0, !1), a }, hooks: { all: {}, add: function (e, t) { var a = n.hooks.all; a[e] = a[e] || [], a[e].push(t) }, run: function (e, t) { var a = n.hooks.all[e]; if (a && a.length) for (var r, i = 0; r = a[i++];)r(t) } } }, a = n.Token = function (e, t, n, a, r) { this.type = e, this.content = t, this.alias = n, this.length = 0 | (a || "").length, this.greedy = !!r }; if (a.stringify = function (e, t, r) { if ("string" == typeof e) return e; if ("Array" === n.util.type(e)) return e.map(function (n) { return a.stringify(n, t, e) }).join(""); var i = { type: e.type, content: a.stringify(e.content, t, r), tag: "span", classes: ["token", e.type], attributes: {}, language: t, parent: r }; if ("comment" == i.type && (i.attributes.spellcheck = "true"), e.alias) { var l = "Array" === n.util.type(e.alias) ? e.alias : [e.alias]; Array.prototype.push.apply(i.classes, l) } n.hooks.run("wrap", i); var o = Object.keys(i.attributes).map(function (e) { return e + '="' + (i.attributes[e] || "").replace(/"/g, "&quot;") + '"' }).join(" "); return "<" + i.tag + ' class="' + i.classes.join(" ") + '"' + (o ? " " + o : "") + ">" + i.content + "</" + i.tag + ">" }, !_self.document) return _self.addEventListener ? (_self.addEventListener("message", function (e) { var t = JSON.parse(e.data), a = t.language, r = t.code, i = t.immediateClose; _self.postMessage(n.highlight(r, n.languages[a], a)), i && _self.close() }, !1), _self.Prism) : _self.Prism; var r = document.currentScript || [].slice.call(document.getElementsByTagName("script")).pop(); return r && (n.filename = r.src, !document.addEventListener || n.manual || r.hasAttribute("data-manual") || ("loading" !== document.readyState ? window.requestAnimationFrame ? window.requestAnimationFrame(n.highlightAll) : window.setTimeout(n.highlightAll, 16) : document.addEventListener("DOMContentLoaded", n.highlightAll))), _self.Prism }(); "undefined" != typeof module && module.exports && (module.exports = Prism), "undefined" != typeof global && (global.Prism = Prism);
Prism.languages.markup = { comment: /<!--[\s\S]*?-->/, prolog: /<\?[\s\S]+?\?>/, doctype: /<!DOCTYPE[\s\S]+?>/i, cdata: /<!\[CDATA\[[\s\S]*?]]>/i, tag: { pattern: /<\/?(?!\d)[^\s>\/=$<]+(?:\s+[^\s>\/=]+(?:=(?:("|')(?:\\\1|\\?(?!\1)[\s\S])*\1|[^\s'">=]+))?)*\s*\/?>/i, inside: { tag: { pattern: /^<\/?[^\s>\/]+/i, inside: { punctuation: /^<\/?/, namespace: /^[^\s>\/:]+:/ } }, "attr-value": { pattern: /=(?:('|")[\s\S]*?(\1)|[^\s>]+)/i, inside: { punctuation: /[=>"']/ } }, punctuation: /\/?>/, "attr-name": { pattern: /[^\s>\/]+/, inside: { namespace: /^[^\s>\/:]+:/ } } } }, entity: /&#?[\da-z]{1,8};/i }, Prism.languages.markup.tag.inside["attr-value"].inside.entity = Prism.languages.markup.entity, Prism.hooks.add("wrap", function (a) { "entity" === a.type && (a.attributes.title = a.content.replace(/&amp;/, "&")) }), Prism.languages.xml = Prism.languages.markup, Prism.languages.html = Prism.languages.markup, Prism.languages.mathml = Prism.languages.markup, Prism.languages.svg = Prism.languages.markup;
Prism.languages.css = { comment: /\/\*[\s\S]*?\*\//, atrule: { pattern: /@[\w-]+?.*?(;|(?=\s*\{))/i, inside: { rule: /@[\w-]+/ } }, url: /url\((?:(["'])(\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1|.*?)\)/i, selector: /[^\{\}\s][^\{\};]*?(?=\s*\{)/, string: { pattern: /("|')(\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/, greedy: !0 }, property: /(\b|\B)[\w-]+(?=\s*:)/i, important: /\B!important\b/i, "function": /[-a-z0-9]+(?=\()/i, punctuation: /[(){};:]/ }, Prism.languages.css.atrule.inside.rest = Prism.util.clone(Prism.languages.css), Prism.languages.markup && (Prism.languages.insertBefore("markup", "tag", { style: { pattern: /(<style[\s\S]*?>)[\s\S]*?(?=<\/style>)/i, lookbehind: !0, inside: Prism.languages.css, alias: "language-css" } }), Prism.languages.insertBefore("inside", "attr-value", { "style-attr": { pattern: /\s*style=("|').*?\1/i, inside: { "attr-name": { pattern: /^\s*style/i, inside: Prism.languages.markup.tag.inside }, punctuation: /^\s*=\s*['"]|['"]\s*$/, "attr-value": { pattern: /.+/i, inside: Prism.languages.css } }, alias: "language-css" } }, Prism.languages.markup.tag));
Prism.languages.clike = { comment: [{ pattern: /(^|[^\\])\/\*[\s\S]*?\*\//, lookbehind: !0 }, { pattern: /(^|[^\\:])\/\/.*/, lookbehind: !0 }], string: { pattern: /(["'])(\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/, greedy: !0 }, "class-name": { pattern: /((?:\b(?:class|interface|extends|implements|trait|instanceof|new)\s+)|(?:catch\s+\())[a-z0-9_\.\\]+/i, lookbehind: !0, inside: { punctuation: /(\.|\\)/ } }, keyword: /\b(if|else|while|do|for|return|in|instanceof|function|new|try|throw|catch|finally|null|break|continue)\b/, "boolean": /\b(true|false)\b/, "function": /[a-z0-9_]+(?=\()/i, number: /\b-?(?:0x[\da-f]+|\d*\.?\d+(?:e[+-]?\d+)?)\b/i, operator: /--?|\+\+?|!=?=?|<=?|>=?|==?=?|&&?|\|\|?|\?|\*|\/|~|\^|%/, punctuation: /[{}[\];(),.:]/ };
Prism.languages.javascript = Prism.languages.extend("clike", { keyword: /\b(as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|var|void|while|with|yield)\b/, number: /\b-?(0[xX][\dA-Fa-f]+|0[bB][01]+|0[oO][0-7]+|\d*\.?\d+([Ee][+-]?\d+)?|NaN|Infinity)\b/, "function": /[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*(?=\()/i, operator: /-[-=]?|\+[+=]?|!=?=?|<<?=?|>>?>?=?|=(?:==?|>)?|&[&=]?|\|[|=]?|\*\*?=?|\/=?|~|\^=?|%=?|\?|\.{3}/ }), Prism.languages.insertBefore("javascript", "keyword", { regex: { pattern: /(^|[^\/])\/(?!\/)(\[[^\]\r\n]+]|\\.|[^\/\\\[\r\n])+\/[gimyu]{0,5}(?=\s*($|[\r\n,.;})]))/, lookbehind: !0, greedy: !0 } }), Prism.languages.insertBefore("javascript", "string", { "template-string": { pattern: /`(?:\\\\|\\?[^\\])*?`/, greedy: !0, inside: { interpolation: { pattern: /\$\{[^}]+\}/, inside: { "interpolation-punctuation": { pattern: /^\$\{|\}$/, alias: "punctuation" }, rest: Prism.languages.javascript } }, string: /[\s\S]+/ } } }), Prism.languages.markup && Prism.languages.insertBefore("markup", "tag", { script: { pattern: /(<script[\s\S]*?>)[\s\S]*?(?=<\/script>)/i, lookbehind: !0, inside: Prism.languages.javascript, alias: "language-javascript" } }), Prism.languages.js = Prism.languages.javascript;



// Vertical bar charts

var ctx = document.getElementById('verticalBarChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['October', 'November', 'December'],
        datasets: [{
            label: ' Paid claims',
          barPercentage: 2,
          barThickness: 50,
            data: [20, 45, 53, 32, 74],
            fill: false,
            backgroundColor: [
                'rgba(99, 153, 174, 1)',
                'rgba(99, 153, 174, 1)',
                'rgba(99, 153, 174, 1)'
            ],
            hoverBackgroundColor: [
                'rgba(99, 153, 174, 1)',
                'rgba(99, 153, 174, 1)',
                'rgba(99, 153, 174, 1)'
            ],

        }]
    },
    options: {
      tooltips:{
        enabled: true,
        backgroundColor: '#47423C',
        borderColor: '#47423C',
        opacity: '0.8',
        font: {
            family: 'verdana',
            size: '14px'
        }
      },
      legend: {
        display: false
      },
        scales: {
          xAxes: [{
                ticks: {
                    beginAtZero: true,
                    fontSize: 15,
                    fontColor: "#453F39",
                    padding: 10
                },
                gridLines:{
                  drawOnChartArea: false,
                  color: "#E4E2E0",
                  drawTicks: false
                }
            }],
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    max: 100,
                    stepSize: 10,
                    fontSize: 15,
                    fontColor: "#453F39",
                    padding: 10
                },
                gridLines:{
                  drawOnChartArea: false,
                  color: "#E4E2E0",
                  drawTicks: false,
                }
            }]
        }
    }
});





// Vertical bar charts

var ctx = document.getElementById('horizontalBarChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'horizontalBar',
    data: {
        labels: ['Emails', 'Phone calls', 'Visits'],
        datasets: [{
            label: 'Total',
          barPercentage: 2,
          barThickness: 50,
            data: [20, 45, 53, 32, 74],
            fill: false,
            backgroundColor: [
                'rgba(136, 141, 48, 1)',
                'rgba(237, 139, 0, 1)',
                'rgba(99, 153, 174, 1)'
            ],
            hoverBackgroundColor: [
                'rgba(136, 141, 48, 1)',
                'rgba(237, 139, 0, 1)',
                'rgba(99, 153, 174, 1)'
            ],

        }]
    },
    options: {
        indexAxis: 'y',
      tooltips:{
        enabled: true,
        backgroundColor: '#47423C',
        borderColor: '#47423C',
        opacity: '0.8',
        font: {
            family: 'verdana',
            size: '14px'
        }
      },
      legend: {
        display: false
      },
        scales: {
          xAxes: [{
                ticks: {
                    beginAtZero: true,
                    fontSize: 15,
                    fontColor: "#453F39",
                    padding: 10
                },
                gridLines:{
                  drawOnChartArea: false,
                  color: "#E4E2E0",
                  drawTicks: false
                }
            }],
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    max: 100,
                    stepSize: 10,
                    fontSize: 15,
                    fontColor: "#453F39",
                    padding: 10
                },
                gridLines:{
                  drawOnChartArea: false,
                  color: "#E4E2E0",
                  drawTicks: false,
                }
            }]
        }
    }
});

$('.expand-card-more').click(function (e)
{
  e.preventDefault();

  box = $(this).parentsUntil('.expand-card').parent().find('.expand-card-body')
  minHeight = 0;

  currentHeight = box.innerHeight();
  maxHeight = box.css('height', 'auto').innerHeight();

  box.css('height', currentHeight).animate({ height: (currentHeight == maxHeight ? minHeight : maxHeight), margin: (currentHeight == maxHeight ? '0px' : '20px 0') }, 300);
  if (currentHeight != maxHeight) {
    $(this).html('Close');
  } else {
    $(this).html('Edit');
  }

})
